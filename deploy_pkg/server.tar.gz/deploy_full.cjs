const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SSH_CONFIG = {
  host: '72.61.116.247',
  port: 22,
  username: 'root',
  password: 'P&e@l;CP8EbIBsrKJaE2',
  readyTimeout: 60000,
};

function runSSH(conn, cmd) {
  return new Promise((resolve, reject) => {
    console.log(`[VPS EXEC] ${cmd}`);
    conn.exec(cmd, (err, stream) => {
      if (err) return reject(err);
      let stdout = '';
      let stderr = '';
      stream.on('close', (code) => {
        if (code !== 0) {
          console.error(`[VPS ERROR ${code}]`);
          return reject(new Error(`Command failed with code ${code}: ${stderr || stdout}`));
        }
        resolve({ code, stdout, stderr });
      }).on('data', (d) => {
        stdout += d.toString();
        process.stdout.write(d.toString());
      }).stderr.on('data', (d) => {
        stderr += d.toString();
        process.stderr.write(d.toString());
      });
    });
  });
}

function uploadFile(conn, localPath, remotePath) {
  return new Promise((resolve, reject) => {
    console.log(`[SFTP UPLOAD] ${localPath} -> ${remotePath}`);
    conn.sftp((err, sftp) => {
      if (err) return reject(err);
      const readStream = fs.createReadStream(localPath);
      const writeStream = sftp.createWriteStream(remotePath);
      writeStream.on('close', () => {
        console.log(`[SFTP DONE] Uploaded ${path.basename(localPath)}`);
        resolve();
      });
      writeStream.on('error', (e) => reject(e));
      readStream.pipe(writeStream);
    });
  });
}

async function main() {
  console.log('=== Step 1: Packaging Local Codebases ===');
  const serverDir = path.resolve(__dirname, '.');
  const frontendDir = path.resolve(__dirname, '../ShebaMitro-health-frontend');
  const tempDir = path.resolve(__dirname, 'deploy_pkg');

  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
  }

  const serverTar = path.join(tempDir, 'server.tar.gz');
  const frontendTar = path.join(tempDir, 'frontend.tar.gz');

  console.log('Creating server archive...');
  execSync(`tar --exclude="node_modules" --exclude="dist" --exclude=".git" --exclude="deploy_pkg" -czf "${serverTar}" .`, {
    cwd: serverDir,
    stdio: 'inherit',
  });

  console.log('Creating frontend archive...');
  execSync(`tar --exclude="node_modules" --exclude=".next" --exclude=".git" -czf "${frontendTar}" .`, {
    cwd: frontendDir,
    stdio: 'inherit',
  });

  console.log('=== Step 2: Connecting to VPS via SSH ===');
  const conn = new Client();

  await new Promise((resolve, reject) => {
    conn.on('ready', resolve);
    conn.on('error', reject);
    conn.connect(SSH_CONFIG);
  });
  console.log('Connected to VPS successfully.');

  console.log('=== Step 3: Preparing Directories on VPS ===');
  await runSSH(conn, `mkdir -p /var/www/shebamitro/server /var/www/shebamitro/frontend /var/www/shebamitro/temp /var/www/shebamitro/server/uploads/images /var/www/shebamitro/server/uploads/avatars && chmod -R 777 /var/www/shebamitro/server/uploads`);

  console.log('=== Step 4: Uploading Archives via SFTP ===');
  await uploadFile(conn, serverTar, '/var/www/shebamitro/temp/server.tar.gz');
  await uploadFile(conn, frontendTar, '/var/www/shebamitro/temp/frontend.tar.gz');

  console.log('=== Step 5: Extracting and Deploying Server ===');
  await runSSH(conn, `
    cd /var/www/shebamitro/server &&
    tar -xzf /var/www/shebamitro/temp/server.tar.gz &&
    mkdir -p /var/www/shebamitro/server/uploads/images /var/www/shebamitro/server/uploads/avatars &&
    chmod -R 777 /var/www/shebamitro/server/uploads &&
    cp .env.production .env &&
    npm install &&
    npx prisma generate &&
    npx prisma db push --accept-data-loss &&
    npm run db:seed &&
    npx ts-node src/database/seed-medicines.ts &&
    npx ts-node src/database/seed-labs.ts &&
    npm run build
  `);

  console.log('=== Step 6: Extracting and Deploying Frontend ===');
  await runSSH(conn, `
    cd /var/www/shebamitro/frontend &&
    rm -f src/middleware.ts &&
    tar -xzf /var/www/shebamitro/temp/frontend.tar.gz &&
    rm -f src/middleware.ts &&
    cp .env.production .env.local &&
    cp .env.production .env &&
    npm install &&
    npm run build
  `);

  console.log('=== Step 7: Managing PM2 Processes ===');
  await runSSH(conn, `
    pm2 delete shebamitro-backend || true
    pm2 delete shebamitro-frontend || true

    cd /var/www/shebamitro/server &&
    pm2 start dist/main.js --name shebamitro-backend --update-env

    cd /var/www/shebamitro/frontend &&
    pm2 start node_modules/next/dist/bin/next --name shebamitro-frontend --update-env -- start -p 3020

    pm2 save
    pm2 list
  `);

  console.log('=== Step 8: Updating Nginx and Verifying Health ===');
  await runSSH(conn, `
    cat << 'EOF' > /etc/nginx/sites-available/shebamitro.conf
# ShebaMitro Frontend Web Application
server {
    server_name shebamitro.web.mirnoman.com;

    client_max_body_size 50M;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        proxy_pass http://127.0.0.1:3020;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/shebamitro.web.mirnoman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/shebamitro.web.mirnoman.com/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
}

# ShebaMitro Backend REST API & Swagger Docs
server {
    server_name shebamitro.api.mirnoman.com;

    client_max_body_size 100M;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    # Redirect root to Swagger API documentation
    location = / {
        return 302 /docs;
    }

    # Uploads & Media Images Direct Static Serving
    location /uploads/ {
        alias /var/www/shebamitro/server/uploads/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }

    location / {
        proxy_pass http://127.0.0.1:5020;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/shebamitro.web.mirnoman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/shebamitro.web.mirnoman.com/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
}

# HTTP to HTTPS redirects
server {
    listen 80;
    server_name shebamitro.web.mirnoman.com;
    return 301 https://$host$request_uri;
}

server {
    listen 80;
    server_name shebamitro.api.mirnoman.com;
    return 301 https://$host$request_uri;
}
EOF

    nginx -t && systemctl reload nginx
    sleep 3
    echo "--- Health Status Backend ---"
    curl -I https://shebamitro.api.mirnoman.com/api/v1/health || true
    echo "--- Health Status Frontend ---"
    curl -I https://shebamitro.web.mirnoman.com || true
    echo "--- Health Status Uploads Image ---"
    curl -I https://shebamitro.api.mirnoman.com/uploads/images/test-body-1791870745557-djvxvs.jpg || true
    echo "--- Health Status Frontend Hero Image ---"
    curl -I https://shebamitro.web.mirnoman.com/images/hero-doctor.jpg || true
  `);

  conn.end();
  console.log('=== DEPLOYMENT COMPLETED SUCCESSFULLY ===');
}

main().catch((err) => {
  console.error('Deployment Failed:', err);
  process.exit(1);
});
