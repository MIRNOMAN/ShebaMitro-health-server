const { runSSHCommand } = require('./ssh_runner.cjs');

async function setupNginx() {
  console.log('--- Creating initial Nginx config for ShebaMitro ---');
  const initialNginxConfig = `
server {
    listen 80;
    server_name shebamitro.web.mirnoman.com;

    client_max_body_size 50M;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        proxy_pass http://127.0.0.1:3020;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \\$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \\$host;
        proxy_cache_bypass \\$http_upgrade;
        proxy_set_header X-Real-IP \\$remote_addr;
        proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \\$scheme;
    }
}

server {
    listen 80;
    server_name shebamitro.api.mirnoman.com;

    client_max_body_size 100M;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        proxy_pass http://127.0.0.1:5020;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \\$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \\$host;
        proxy_cache_bypass \\$http_upgrade;
        proxy_set_header X-Real-IP \\$remote_addr;
        proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \\$scheme;
    }
}
`;

  await runSSHCommand(`cat << 'EOF' > /etc/nginx/sites-available/shebamitro.conf
${initialNginxConfig}
EOF`);

  await runSSHCommand(`ln -sf /etc/nginx/sites-available/shebamitro.conf /etc/nginx/sites-enabled/shebamitro.conf`);
  await runSSHCommand(`nginx -t && systemctl reload nginx`);

  console.log('--- Obtaining Let\'s Encrypt SSL Certificates ---');
  const certbotRes = await runSSHCommand(`certbot --nginx -d shebamitro.web.mirnoman.com -d shebamitro.api.mirnoman.com --non-interactive --agree-tos -m abdullahalnoman1509@gmail.com --redirect`);
  console.log('Certbot result code:', certbotRes.code);

  await runSSHCommand(`nginx -t && systemctl reload nginx`);
  console.log('Nginx & SSL configured successfully!');
}

setupNginx().catch(err => {
  console.error('Nginx setup error:', err);
  process.exit(1);
});
