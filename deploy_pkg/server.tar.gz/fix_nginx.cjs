const { runSSHCommand } = require('./ssh_runner.cjs');

async function fixNginx() {
  const correctConfig = `
# ShebaMitro Frontend Web Application
server {
    server_name shebamitro.web.mirnoman.com;

    client_max_body_size 50M;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        proxy_pass http://127.0.0.1:3020;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/shebamitro.web.mirnoman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/shebamitro.web.mirnoman.com/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
}

# ShebaMitro Backend REST API & Swagger Docs
server {
    server_name shebamitro.api.mirnoman.com;

    client_max_body_size 100M;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    # Redirect root to Swagger API documentation
    location = / {
        return 302 /docs;
    }

    location / {
        proxy_pass http://127.0.0.1:5020;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/shebamitro.web.mirnoman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/shebamitro.web.mirnoman.com/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
}

# HTTP to HTTPS redirects
server {
    listen 80;
    server_name shebamitro.web.mirnoman.com;
    return 301 https://$host$request_uri;
}

server {
    listen 80;
    server_name shebamitro.api.mirnoman.com;
    return 301 https://$host$request_uri;
}
`;

  console.log('Writing updated Nginx config with /docs redirect...');
  await runSSHCommand(`cat << 'EOF' > /etc/nginx/sites-available/shebamitro.conf
${correctConfig}
EOF`);

  await runSSHCommand(`nginx -t && systemctl reload nginx`);

  console.log('Testing HTTPS endpoints via curl...');
  await runSSHCommand(`
    curl -IL https://shebamitro.web.mirnoman.com
    echo "---"
    curl -IL https://shebamitro.api.mirnoman.com/
  `);
}

fixNginx().catch(console.error);
