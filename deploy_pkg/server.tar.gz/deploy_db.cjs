const { runSSHCommand } = require('./ssh_runner.cjs');

async function setupDatabase() {
  const sqlCommands = [
    `sudo -u postgres psql -c "DO \\$\\$ BEGIN IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'shebamitro_user') THEN CREATE USER shebamitro_user WITH PASSWORD 'ShebaMitroSecureDb2026!' SUPERUSER CREATEDB; END IF; END \\$\\$;"`,
    `sudo -u postgres psql -c "ALTER USER shebamitro_user WITH PASSWORD 'ShebaMitroSecureDb2026!';"`,
    `sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname = 'shebamitro_db'" | grep -q 1 || sudo -u postgres psql -c "CREATE DATABASE shebamitro_db OWNER shebamitro_user;"`,
    `sudo -u postgres psql -d shebamitro_db -c 'CREATE EXTENSION IF NOT EXISTS "pg_trgm"; CREATE EXTENSION IF NOT EXISTS "uuid-ossp"; CREATE EXTENSION IF NOT EXISTS "btree_gin";'`,
    `PGPASSWORD='ShebaMitroSecureDb2026!' psql -U shebamitro_user -h 127.0.0.1 -d shebamitro_db -c 'SELECT 1 as connected;'`
  ];

  for (const cmd of sqlCommands) {
    console.log(`Executing: ${cmd}`);
    const res = await runSSHCommand(cmd);
    console.log(`Exit code: ${res.code}`);
    if (res.code !== 0) {
      throw new Error(`Command failed with code ${res.code}: ${res.stderr || res.stdout}`);
    }
  }
  console.log('Database successfully configured and tested!');
}

setupDatabase().catch(err => {
  console.error('Setup failed:', err);
  process.exit(1);
});
