import {
  Injectable,
  Logger,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { ReminderStatus, MealTiming } from '@prisma/client';
import { PrismaService } from '../../database/prisma.service.js';
import { RemindersQueueService } from './reminders-queue.service.js';
import { WebPushService } from './web-push.service.js';
import { CreateReminderDto } from './dto/create-reminder.dto.js';

export interface ParseAndScheduleInput {
  patientId: string;
  prescriptionItemId: string;
  schedulePattern: string; // e.g. "1+0+1", "1+1+1", "1+0+0", "0+0+1"
  durationDays: number; // e.g. 7
  timezone?: string; // e.g. "Asia/Dhaka" (+06:00) or UTC offset
  startDate?: Date;
}

export interface DosageSlot {
  hours: number;
  minutes: number;
  label: string;
}

@Injectable()
export class DosageParserService {
  private readonly logger = new Logger(DosageParserService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly remindersQueueService: RemindersQueueService,
    private readonly webPushService: WebPushService,
  ) {}

  /**
   * Parse pattern (e.g. "1+0+1") into dosage time slots (e.g. 08:30 AM and 09:00 PM)
   */
  parseSchedulePattern(pattern: string): DosageSlot[] {
    const cleaned = pattern.replace(/\s+/g, '').trim();
    const slots: DosageSlot[] = [];

    // Pattern like "1+0+1" or "1+1+1" or "1-0-1"
    const parts = cleaned.split(/[\+\-,\/]/);

    if (parts.length === 3) {
      // Morning (1+0+0), Afternoon (0+1+0), Evening/Night (0+0+1)
      if (parseInt(parts[0], 10) > 0) {
        slots.push({ hours: 8, minutes: 30, label: 'Morning (08:30 AM)' });
      }
      if (parseInt(parts[1], 10) > 0) {
        slots.push({ hours: 13, minutes: 30, label: 'Afternoon (01:30 PM)' });
      }
      if (parseInt(parts[2], 10) > 0) {
        slots.push({ hours: 21, minutes: 0, label: 'Night (09:00 PM)' });
      }
    } else if (parts.length === 4) {
      // 4 times a day: 08:00 AM, 12:00 PM, 05:00 PM, 09:00 PM
      if (parseInt(parts[0], 10) > 0)
        slots.push({ hours: 8, minutes: 0, label: 'Morning (08:00 AM)' });
      if (parseInt(parts[1], 10) > 0)
        slots.push({ hours: 12, minutes: 0, label: 'Noon (12:00 PM)' });
      if (parseInt(parts[2], 10) > 0)
        slots.push({ hours: 17, minutes: 0, label: 'Evening (05:00 PM)' });
      if (parseInt(parts[3], 10) > 0)
        slots.push({ hours: 21, minutes: 0, label: 'Night (09:00 PM)' });
    } else if (parts.length === 2) {
      // 2 times a day: 08:30 AM, 08:30 PM
      if (parseInt(parts[0], 10) > 0)
        slots.push({ hours: 8, minutes: 30, label: 'Morning (08:30 AM)' });
      if (parseInt(parts[1], 10) > 0)
        slots.push({ hours: 20, minutes: 30, label: 'Night (08:30 PM)' });
    } else {
      // Fallback default: Morning 08:30 AM & Night 09:00 PM
      slots.push({ hours: 8, minutes: 30, label: 'Morning (08:30 AM)' });
      slots.push({ hours: 21, minutes: 0, label: 'Night (09:00 PM)' });
    }

    return slots;
  }

  /**
   * Calculate exact scheduled timestamps adjusted for patient timezone offset
   */
  calculateScheduledTimestamps(
    pattern: string,
    durationDays: number,
    timezoneOffsetMinutes: number = -360, // Default Asia/Dhaka (+06:00 = -360 UTC offset)
    startDate: Date = new Date(),
  ): Date[] {
    const slots = this.parseSchedulePattern(pattern);
    const timestamps: Date[] = [];

    const baseYear = startDate.getUTCFullYear();
    const baseMonth = startDate.getUTCMonth();
    const baseDay = startDate.getUTCDate();

    for (let dayIndex = 0; dayIndex < durationDays; dayIndex++) {
      for (const slot of slots) {
        // Compute timestamp in patient timezone (adjusting for UTC offset)
        const scheduledDate = new Date(
          Date.UTC(
            baseYear,
            baseMonth,
            baseDay + dayIndex,
            slot.hours,
            slot.minutes,
            0,
            0,
          ),
        );

        // Adjust for timezone offset (e.g. +6 hours = -360 mins from UTC)
        scheduledDate.setMinutes(
          scheduledDate.getMinutes() + timezoneOffsetMinutes,
        );

        timestamps.push(scheduledDate);
      }
    }

    return timestamps;
  }

  /**
   * Parse pattern, bulk insert MedicineReminder records into DB, and schedule delayed BullMQ jobs
   */
  async parseAndScheduleItemReminders(input: ParseAndScheduleInput) {
    const {
      patientId,
      prescriptionItemId,
      schedulePattern,
      durationDays,
      startDate,
    } = input;

    // 1. Calculate exact dosage timestamps across treatment duration
    const timestamps = this.calculateScheduledTimestamps(
      schedulePattern,
      durationDays,
      -360, // Asia/Dhaka (+06:00) timezone offset
      startDate || new Date(),
    );

    this.logger.log(
      `Parsed pattern "${schedulePattern}" for ${durationDays} days: generated ${timestamps.length} dosage timestamps`,
    );

    // 2. Bulk insert MedicineReminder records into DB
    const reminderRecords = timestamps.map((intakeTime) => ({
      patientId,
      prescriptionItemId,
      intakeTime,
      status: ReminderStatus.PENDING,
    }));

    await this.prisma.medicineReminder.createMany({
      data: reminderRecords,
    });

    // 3. Fetch newly created reminders from DB to obtain generated IDs
    const createdReminders = await this.prisma.medicineReminder.findMany({
      where: {
        prescriptionItemId,
        patientId,
        status: ReminderStatus.PENDING,
      },
      orderBy: { intakeTime: 'asc' },
    });

    // 4. Schedule corresponding delayed BullMQ jobs with unique job IDs
    for (const reminder of createdReminders) {
      await this.remindersQueueService.addReminderJob({
        reminderId: reminder.id,
        patientId: reminder.patientId,
        prescriptionItemId: reminder.prescriptionItemId,
        intakeTime: reminder.intakeTime,
      });
    }

    this.logger.log(
      `Successfully created ${createdReminders.length} MedicineReminder DB records and scheduled BullMQ delayed jobs for prescription item ${prescriptionItemId}`,
    );

    return createdReminders;
  }

  /**
   * Record TAKEN or SKIPPED status for a medicine reminder and compute patient compliance rate
   */
  async acknowledgeReminder(
    userId: string | undefined,
    reminderId: string,
    status: ReminderStatus,
  ) {
    let patientProfile = null;
    if (userId) {
      patientProfile = await this.prisma.patientProfile.findUnique({
        where: { userId },
      });
    }

    const reminder = await this.prisma.medicineReminder.findUnique({
      where: { id: reminderId },
    });

    if (!reminder) {
      throw new NotFoundException(
        `Medicine reminder with ID ${reminderId} not found`,
      );
    }

    if (patientProfile && reminder.patientId !== patientProfile.id) {
      throw new ForbiddenException(
        'Access denied. You do not have permission to acknowledge this reminder.',
      );
    }

    const updatedReminder = await this.prisma.medicineReminder.update({
      where: { id: reminderId },
      data: {
        status,
        acknowledgedAt: new Date(),
      },
    });

    // Compute patient compliance rate across all reminders
    const allReminders = await this.prisma.medicineReminder.findMany({
      where: { patientId: reminder.patientId },
    });

    const totalReminders = allReminders.length;
    const takenCount = allReminders.filter(
      (r) => r.status === ReminderStatus.TAKEN,
    ).length;
    const skippedCount = allReminders.filter(
      (r) => r.status === ReminderStatus.SKIPPED,
    ).length;
    const pendingCount = allReminders.filter(
      (r) => r.status === ReminderStatus.PENDING,
    ).length;

    const complianceRate =
      totalReminders > 0
        ? Number(((takenCount / totalReminders) * 100).toFixed(1))
        : 0;

    this.logger.log(
      `Patient ${reminder.patientId} acknowledged reminder ${reminderId} as ${status}. Updated compliance rate: ${complianceRate}%`,
    );

    return {
      reminder: updatedReminder,
      complianceRate,
      complianceSummary: {
        totalReminders,
        takenCount,
        skippedCount,
        pendingCount,
        complianceRatePercentage: complianceRate,
      },
    };
  }

  /**
   * Snooze medicine reminder alarm by 15 or 30 minutes in BullMQ and DB
   */
  async snoozeReminder(
    userId: string | undefined,
    reminderId: string,
    snoozeMinutes: number = 15,
  ) {
    let patientProfile = null;
    if (userId) {
      patientProfile = await this.prisma.patientProfile.findUnique({
        where: { userId },
      });
    }

    const reminder = await this.prisma.medicineReminder.findUnique({
      where: { id: reminderId },
      include: { prescriptionItem: true },
    });

    if (!reminder) {
      throw new NotFoundException(
        `Medicine reminder with ID ${reminderId} not found`,
      );
    }

    if (patientProfile && reminder.patientId !== patientProfile.id) {
      throw new ForbiddenException(
        'Access denied. You do not have permission to snooze this reminder.',
      );
    }

    const newIntakeTime = new Date(Date.now() + snoozeMinutes * 60 * 1000);

    // Update intake time in DB
    const updatedReminder = await this.prisma.medicineReminder.update({
      where: { id: reminderId },
      data: {
        intakeTime: newIntakeTime,
        status: ReminderStatus.PENDING,
      },
    });

    // Reschedule delayed BullMQ job
    await this.remindersQueueService.snoozeReminderJob(
      {
        reminderId: reminder.id,
        patientId: reminder.patientId,
        prescriptionItemId: reminder.prescriptionItemId,
        intakeTime: newIntakeTime,
      },
      snoozeMinutes,
    );

    this.logger.log(
      `Patient ${reminder.patientId} snoozed reminder ${reminderId} by ${snoozeMinutes} mins to ${newIntakeTime.toISOString()}`,
    );

    return {
      reminder: updatedReminder,
      snoozedByMinutes: snoozeMinutes,
      newIntakeTime,
      message: `Alarm snoozed successfully by ${snoozeMinutes} minutes.`,
    };
  }

  /**
   * GET /api/v1/reminders/compliance/:patientId
   * Calculate adherence percentage (Doses Taken on Time / Total Prescribed Doses).
   * If adherence falls below 70%, trigger automated push reminder to patient
   * and flag an adherence alert on doctor's upcoming follow-up appointment view.
   */
  async getPatientCompliance(patientId: string) {
    const patientProfile = await this.prisma.patientProfile.findUnique({
      where: { id: patientId },
      include: {
        user: { select: { name: true, email: true, phone: true } },
      },
    });

    if (!patientProfile) {
      throw new NotFoundException(
        `Patient profile with ID ${patientId} not found`,
      );
    }

    const allReminders = await this.prisma.medicineReminder.findMany({
      where: { patientId },
      include: { prescriptionItem: true },
    });

    const totalPrescribedDoses = allReminders.length;
    const dosesTakenOnTime = allReminders.filter(
      (r) => r.status === ReminderStatus.TAKEN,
    ).length;
    const skippedDoses = allReminders.filter(
      (r) => r.status === ReminderStatus.SKIPPED,
    ).length;
    const pendingDoses = allReminders.filter(
      (r) => r.status === ReminderStatus.PENDING,
    ).length;

    const adherencePercentage =
      totalPrescribedDoses > 0
        ? Number(((dosesTakenOnTime / totalPrescribedDoses) * 100).toFixed(1))
        : 100;

    let adherenceAlertTriggered = false;
    let pushNotificationSent = false;
    let flaggedAppointmentsCount = 0;

    // If adherence falls below 70%
    if (adherencePercentage < 70) {
      adherenceAlertTriggered = true;

      // 1) Trigger automated push reminder to patient
      try {
        await this.webPushService.sendAlarmNotification(patientId, {
          reminderId: `compliance-alert-${Date.now()}`,
          patientId,
          medicineName: 'Low Medication Adherence Warning',
          schedulePattern: `Current Adherence: ${adherencePercentage}% (<70%)`,
          intakeTime: new Date(),
        });
        pushNotificationSent = true;
      } catch (err: any) {
        this.logger.warn(
          `Failed to dispatch low adherence push notification: ${err.message}`,
        );
      }

      // 2) Flag adherence alert on doctor's upcoming follow-up appointment view
      const upcomingAppointments = await this.prisma.appointment.findMany({
        where: {
          patientId,
          slotStartTime: { gte: new Date() },
          status: { in: ['CONFIRMED', 'PENDING', 'IN_PROGRESS'] as any },
        },
      });

      const alertTag = `[ADHERENCE ALERT: Patient medication adherence is ${adherencePercentage}% (<70%)]`;

      for (const appt of upcomingAppointments) {
        const updatedNotes = appt.notes
          ? `${appt.notes}\n${alertTag}`
          : alertTag;

        if (!appt.notes?.includes('ADHERENCE ALERT')) {
          await this.prisma.appointment.update({
            where: { id: appt.id },
            data: { notes: updatedNotes },
          });
          flaggedAppointmentsCount++;
        }
      }

      this.logger.warn(
        `Low adherence alert (<70%) triggered for patient ${patientId}: Adherence is ${adherencePercentage}%. Push sent: ${pushNotificationSent}. Flagged ${flaggedAppointmentsCount} upcoming appointments.`,
      );
    }

    return {
      patientId,
      patientName: patientProfile.user?.name || 'Patient',
      adherencePercentage,
      dosesTakenOnTime,
      totalPrescribedDoses,
      skippedDoses,
      pendingDoses,
      adherenceAlertTriggered,
      alertThreshold: 70,
      pushNotificationSent,
      flaggedUpcomingAppointmentsCount: flaggedAppointmentsCount,
    };
  }

  /**
   * Get all reminders for patient with compliance and summary
   */
  async getPatientReminders(userId?: string, queryPatientId?: string) {
    let patientId = queryPatientId;

    if (!patientId && userId) {
      const profile = await this.prisma.patientProfile.findUnique({
        where: { userId },
      });
      patientId = profile?.id;
    }

    if (!patientId) {
      // Fallback to active demo patient in database
      const firstPatient = await this.prisma.patientProfile.findFirst({
        where: { deletedAt: null },
      });
      patientId = firstPatient?.id;
    }

    if (!patientId) {
      return {
        reminders: [],
        complianceRate: 100,
        summary: { total: 0, taken: 0, pending: 0, skipped: 0 },
      };
    }

    const reminders = await this.prisma.medicineReminder.findMany({
      where: { patientId },
      include: {
        prescriptionItem: true,
      },
      orderBy: { intakeTime: 'asc' },
    });

    const total = reminders.length;
    const taken = reminders.filter(
      (r) => r.status === ReminderStatus.TAKEN,
    ).length;
    const pending = reminders.filter(
      (r) => r.status === ReminderStatus.PENDING,
    ).length;
    const skipped = reminders.filter(
      (r) => r.status === ReminderStatus.SKIPPED,
    ).length;
    const complianceRate =
      total > 0 ? Number(((taken / total) * 100).toFixed(1)) : 100;

    return {
      reminders,
      complianceRate,
      summary: {
        total,
        taken,
        pending,
        skipped,
      },
    };
  }

  /**
   * Create custom medication schedule / reminder directly in DB
   */
  async createCustomReminder(userId?: string, dto?: any) {
    let patientId: string | undefined;

    if (userId) {
      const profile = await this.prisma.patientProfile.findUnique({
        where: { userId },
      });
      patientId = profile?.id;
    }

    if (!patientId) {
      const firstPatient = await this.prisma.patientProfile.findFirst({
        where: { deletedAt: null },
      });
      patientId = firstPatient?.id;
    }

    if (!patientId) {
      throw new NotFoundException(
        'Patient record not found to attach reminder.',
      );
    }

    // Find or create prescription to hold item
    let prescription = await this.prisma.prescription.findFirst({
      where: { patientId, deletedAt: null },
    });

    if (!prescription) {
      const doctor = await this.prisma.doctorProfile.findFirst();
      if (!doctor) throw new NotFoundException('No doctor profile found.');

      const appt = await this.prisma.appointment.create({
        data: {
          doctorId: doctor.id,
          patientId,
          slotStartTime: new Date(),
          slotEndTime: new Date(Date.now() + 30 * 60 * 1000),
          status: 'COMPLETED',
          paymentStatus: 'PAID',
        },
      });

      prescription = await this.prisma.prescription.create({
        data: {
          appointmentId: appt.id,
          doctorId: doctor.id,
          patientId,
          diagnosis: 'Self-Managed Medication Schedule',
          advice: 'Follow scheduled alarm timings.',
        },
      });
    }

    // Create prescription item
    const prescriptionItem = await this.prisma.prescriptionItem.create({
      data: {
        prescriptionId: prescription.id,
        medicineName: dto.medicineName,
        genericName: dto.genericName || null,
        dosageForm: dto.dosageForm || 'Tablet',
        schedulePattern: dto.schedulePattern || '1+0+1',
        mealTiming: dto.mealTiming || 'AFTER_MEAL',
        durationDays: dto.durationDays || 7,
      },
    });

    // Compute intake time: use provided or next slot
    let intakeTime = new Date();
    if (dto.intakeTime) {
      const parsed = new Date(dto.intakeTime);
      if (!isNaN(parsed.getTime())) intakeTime = parsed;
    } else {
      intakeTime = new Date(Date.now() + 30 * 60 * 1000); // 30 mins from now
    }

    // Create the medicine reminder record
    const reminder = await this.prisma.medicineReminder.create({
      data: {
        patientId,
        prescriptionItemId: prescriptionItem.id,
        intakeTime,
        status: 'PENDING',
      },
      include: {
        prescriptionItem: true,
      },
    });

    return reminder;
  }

  /**
   * Delete medication schedule / reminder from DB
   */
  async deleteReminder(userId?: string, reminderId?: string) {
    const reminder = await this.prisma.medicineReminder.findUnique({
      where: { id: reminderId },
    });

    if (!reminder) {
      throw new NotFoundException(`Reminder with ID ${reminderId} not found`);
    }

    await this.prisma.medicineReminder.delete({
      where: { id: reminderId },
    });

    return {
      success: true,
      message: 'Medication reminder removed successfully',
    };
  }
}
