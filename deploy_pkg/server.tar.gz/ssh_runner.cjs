const { Client } = require('ssh2');

function runSSHCommand(cmd) {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    const config = {
      host: '72.61.116.247',
      port: 22,
      username: 'root',
      password: 'P&e@l;CP8EbIBsrKJaE2',
      readyTimeout: 30000,
    };

    conn.on('ready', () => {
      conn.exec(cmd, (err, stream) => {
        if (err) {
          conn.end();
          return reject(err);
        }
        let stdout = '';
        let stderr = '';
        stream.on('close', (code, signal) => {
          conn.end();
          resolve({ code, stdout, stderr });
        }).on('data', (data) => {
          stdout += data.toString();
          process.stdout.write(data.toString());
        }).stderr.on('data', (data) => {
          stderr += data.toString();
          process.stderr.write(data.toString());
        });
      });
    }).on('error', (err) => {
      reject(err);
    }).connect(config);
  });
}

module.exports = { runSSHCommand };

if (require.main === module) {
  const cmd = process.argv.slice(2).join(' ') || 'uname -a && lsb_release -a && free -h && df -h && docker --version 2>&1 || echo "docker status check"';
  console.log('Running remote command:', cmd);
  runSSHCommand(cmd)
    .then((res) => {
      console.log('\n--- Finished with code ' + res.code + ' ---');
    })
    .catch((e) => {
      console.error('SSH error:', e);
    });
}
