const { Client } = require('ssh2');

const users = ['root', 'vivekbelani', 'ubuntu'];

// Variations of characters in P&e@I;CP8EbIBsrKJaE2
// Position 4: I, l, |, 1, i
// Position 12: I, l, |, 1, i
const char1_opts = ['I', 'l', '|', '1', 'i'];
const char2_opts = ['I', 'l', '|', '1', 'i'];

const passwords = new Set([
  'P&e@I;CP8EbIBsrKJaE2',
  'P&e@l;CP8EbIBsrKJaE2',
  'P&e@I;CP8EblBsrKJaE2',
  'P&e@l;CP8EblBsrKJaE2',
  'P&e@1;CP8Eb1BsrKJaE2',
  'P&e@|;CP8Eb|BsrKJaE2',
  'P&e@l;CP8Eb|BsrKJaE2',
  'P&e@|;CP8EblBsrKJaE2',
]);

for (const c1 of char1_opts) {
  for (const c2 of char2_opts) {
    passwords.add(`P&e@${c1};CP8Eb${c2}BsrKJaE2`);
  }
}

async function tryAuth(username, password) {
  return new Promise((resolve) => {
    const conn = new Client();
    conn.on('ready', () => {
      conn.end();
      resolve(true);
    }).on('error', () => {
      resolve(false);
    }).connect({
      host: '72.61.116.247',
      port: 22,
      username,
      password,
      readyTimeout: 8000,
    });
  });
}

async function run() {
  console.log('Testing combinations...');
  for (const user of users) {
    for (const pass of passwords) {
      process.stdout.write(`Testing user=${user} pass=${pass}... `);
      const ok = await tryAuth(user, pass);
      if (ok) {
        console.log('\n>>> SUCCESS! User:', user, 'Password:', pass);
        return;
      }
      console.log('failed');
    }
  }
  console.log('All variations failed.');
}

run();
